import unittest
from unittest.mock import patch
from icompte import ICompte
from comptes.comptebancaire import CompteBancaire
from comptes.compteepargne import CompteEpargne
from client import Client

class TestCompteBancaires(unittest.TestCase):
    """
    Tests pour la classe CompteBancaire.
    """
    def setUp(self):
        self.compte = CompteBancaire("Alice", 1000.0)

    def test_initialisation(self):
        self.assertEqual(self.compte.titulaire, "Alice")
        self.assertEqual(self.compte.solde, 1000.0)

    def test_depot(self):
        self.compte.depot(500.0)
        self.assertEqual(self.compte.solde, 1500.0)
        with self.assertRaises(ValueError):
            self.compte.depot(-100.0)
        self.assertEqual(self.compte.solde, 1500.0)

    def test_retrait(self):
        self.compte.retrait(200.0)
        self.assertEqual(self.compte.solde, 800.0)
        with self.assertRaises(ValueError):
            self.compte.retrait(900.0)
        self.assertEqual(self.compte.solde, 800.0)

    def test_afficher(self):
        self.assertEqual(self.compte.afficher(), "Titulaire: Alice, Solde: 1000.00 €")
        self.compte.depot(500.0)
        self.assertEqual(self.compte.afficher(), "Titulaire: Alice, Solde: 1500.00 €")


class TestCompteEpargne(unittest.TestCase):
    def setUp(self):
        self.compte_epargne = CompteEpargne("Alice", 1000.0, 2.0)

    def test_initialisation(self):
        self.assertEqual(self.compte_epargne.titulaire, "Alice")
        self.assertEqual(self.compte_epargne.solde, 1000.0)
        self.assertEqual(self.compte_epargne._taux_interet, 2.0)

    def test_ajouter_interets(self):
        interets = self.compte_epargne.ajouter_interets()
        self.assertEqual(interets, 20.0)
        self.assertEqual(self.compte_epargne.solde, 1020.0)

    def test_calculer_interets(self):
        interets = self.compte_epargne.calculer_interets()
        self.assertEqual(interets, 20.0)

class TestClient(unittest.TestCase):

    def setUp(self):
        self.client = Client("Alice")

    def test_initialisation(self):
        self.assertEqual(self.client.nom, "Alice")
        self.assertEqual(self.client.comptes, [])
        self.client.ajouter_compte(CompteBancaire("Alice", 1000.0))
        self.assertEqual(len(self.client.comptes), 1)

    def test_ajouter_compte(self):
        compte = CompteBancaire("Alice", 1000.0)
        self.client.ajouter_compte(compte)
        self.assertIn(compte, self.client.comptes)

    def test_supprimer_compte(self):
        compte = CompteBancaire("Alice", 1000.0)
        self.client.ajouter_compte(compte)
        self.client.supprimer_compte(compte)
        self.assertNotIn(compte, self.client.comptes)

    def test_resume_comptes(self):
        compte1 = CompteBancaire("Alice", 1000.0)
        compte2 = CompteEpargne("Alice", 2000.0, 2.0)
        self.client.ajouter_compte(compte1)
        self.client.ajouter_compte(compte2)

        with patch('builtins.print') as mock_print:
            self.client.resume_comptes()
            mock_print.assert_any_call("Titulaire: Alice, Solde: 1000.00 €")
            mock_print.assert_any_call("Titulaire: Alice, Solde: 2000.00 €")
            mock_print.assert_any_call("Total des comptes: 2")
        self.client.supprimer_compte(compte1)
        self.client.supprimer_compte(compte2)
        self.assertEqual(len(self.client.comptes), 0)

    def test_str(self):
        self.client.ajouter_compte(CompteBancaire("Alice", 1000.0))
        self.assertEqual(str(self.client), "Client: Alice, Comptes: 1")
        self.client.supprimer_compte(self.client.comptes[0])
        self.assertEqual(str(self.client), "Client: Alice, Comptes: 0")



if __name__ == "__main__":
    unittest.main()