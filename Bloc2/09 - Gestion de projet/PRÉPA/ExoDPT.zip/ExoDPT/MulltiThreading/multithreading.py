from comptes.comptebancaire import CompteBancaire

import threading

# Version thread-safe de CompteBancaire + protéger depot et retrait

class CompteBancaireThreadSafe(CompteBancaire):
    def __init__(self, titulaire: str, solde: float):
        super().__init__(titulaire, solde)
        self._lock = threading.RLock()

    def depot(self, montant: float) -> None:
        with self._lock:
            super().depot(montant)

    def retrait(self, montant: float) -> None:
        with self._lock:
            super().retrait(montant)

    def afficher(self) -> str:
        with self._lock:
            return super().afficher()


if __name__ == "__main__":
    compte = CompteBancaireThreadSafe("Alice", 0.0)
    threads = []
    for i in range(5):
        threads.append(
            threading.Thread(
                target=compte.depot,
                args=(10,)
            )
        )
    print(threads)
    for i in range(1000):
        for t in threads:
            t.start()
        for t in threads:
            t.join()
    print(compte.afficher())


