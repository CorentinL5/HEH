from icompte import ICompte
from client import Client

if __name__ == "__main__":
    # Création d'un client
    client = Client("Alice")
    print(client)

    # Ajout d'un compte bancaire
    compte = ICompte()
    client.ajouter_compte(compte)
    print(client)

    # Affichage du résumé des comptes
    client.resume_comptes()

    # Suppression d'un compte
    client.supprimer_compte(compte)
    print(client)