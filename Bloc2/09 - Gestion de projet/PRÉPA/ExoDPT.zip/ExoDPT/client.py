from icompte import ICompte

class Client:
    def __init__(self, nom: str):
        self._nom = nom
        self._comptes = []

    def __str__(self):
        return f"Client: {self._nom}, Comptes: {len(self._comptes)}"

    @property
    def nom(self) -> str:
        return self._nom

    @nom.setter
    def nom(self, nom: str) -> None:
        if not isinstance(nom, str):
            raise ValueError("Le nom doit être une chaîne de caractères")
        self._nom = nom

    @property
    def comptes(self) -> list:
        return self._comptes

    @comptes.setter
    def comptes(self, comptes: list) -> None:
        if not isinstance(comptes, list):
            raise ValueError("Les comptes doivent être une liste")
        self._comptes = comptes

    def ajouter_compte(self, compte: ICompte) -> None:
        if not isinstance(compte, ICompte):
            raise ValueError("L'objet doit être une instance de ICompte")
        self._comptes.append(compte)

    def supprimer_compte(self, compte: ICompte) -> None:
        if not isinstance(compte, ICompte):
            raise ValueError("L'objet doit être une instance de ICompte")
        self._comptes.remove(compte)

    def resume_comptes(self) -> None:
        for compte in self._comptes:
            print(compte.afficher())
        print(f"Total des comptes: {len(self._comptes)}")
    