from comptes.comptebancaire import CompteBancaire

class CompteEpargne(CompteBancaire):
    def __init__(self, titulaire: str, solde: float, taux_interet: float):
        super().__init__(titulaire, solde)
        self._taux_interet = taux_interet

    def __str__(self):
        return f"{super().__str__()}, Taux d'intérêt: {self._taux_interet:.2f} %"

    @property
    def taux_interet(self):
        return self._taux_interet

    @taux_interet.setter
    def taux_interet(self, taux_interet: float):
        if taux_interet < 0:
            raise ValueError("Le taux d'intérets ne peut être inférieur à 0")
        if taux_interet > 100:
            raise ValueError("Le taux d'intérets ne peut être supérieur à 100")
        self._taux_interet = taux_interet


    def calculer_interets(self) -> float:
        return self._solde * self._taux_interet / 100

    def ajouter_interets(self) -> float:
        interets = self.calculer_interets()
        self.depot(interets)
        return interets