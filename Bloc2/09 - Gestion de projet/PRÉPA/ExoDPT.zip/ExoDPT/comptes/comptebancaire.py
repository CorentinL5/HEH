from icompte import ICompte


class CompteBancaire(ICompte):
    def __init__(self, titulaire: str , solde: float):
        self._titulaire = titulaire
        self._solde = solde

    def __str__(self):
        self.afficher()

    @property
    def titulaire(self) -> str:
        return self._titulaire

    @titulaire.setter
    def titulaire(self, nom: str) -> None:
        if not isinstance(nom, str):
            raise ValueError("Le nom doit être une chaîne de caractères")
        self._titulaire = nom

    @property
    def solde(self) -> float:
        return self._solde

    @solde.setter
    def solde(self, montant: float) -> None:
        if montant < 0:
            raise ValueError("Le solde ne peut pas être négatif")
        self._solde = montant


    def depot(self, montant: float) -> None:
        if montant < 0:
            raise ValueError("Le montant doit être positif")
        self._solde += montant

    def retrait(self, montant: float) -> None:
        if montant > self._solde:
            raise ValueError("Fonds insuffisants")
        self._solde -= montant

    def afficher(self) -> str:
        return f"Titulaire: {self._titulaire}, Solde: {self._solde:.2f} €"
