import abc

class ICompte(abc.ABC):
    @abc.abstractmethod
    def depot(self, montant: float) -> None:
        """Dépose un montant sur le compte."""
        pass

    @abc.abstractmethod
    def retrait(self, montant: float) -> None:
        """Retire un montant du compte."""
        pass

    @abc.abstractmethod
    def afficher(self) -> str:
        """Affiche le solde du compte."""
        pass

