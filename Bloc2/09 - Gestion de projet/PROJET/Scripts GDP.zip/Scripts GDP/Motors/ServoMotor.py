import time
from adafruit_motor import servo

class ServoMotor:
    """
    Classe de contrôle d’un servomoteur via PCA9685.

    Attributs :
        - middle_angle : angle central (position de repos)
        - angle_min : angle minimal autorisé
        - angle_max : angle maximal autorisé
        - current_angle : angle actuel du servo
    """

    id = 0

    def __init__(self, pca9685, channel, range_right=35, range_left=35, middle_angle=130):
        """
        Initialise un servomoteur connecté au canal spécifié du PCA9685.

        Args:
            pca9685: instance du contrôleur PCA9685.
            channel: numéro du canal (0-15).
            middle_angle: angle central par défaut.
            range_left: décalage vers la gauche (en degrés).
            range_right: décalage vers la droite (en degrés).
        """
        ServoMotor.id += 1
        self._name = f"DCMotor_{ServoMotor.id}"
        self._channel = pca9685.channels[channel]
        self._servo = servo.Servo(self._channel)
        self._middle_angle = middle_angle
        print(f"middle angle {self._middle_angle}")
        self._angle_min = (middle_angle - range_left) % 180
        self._angle_max = (middle_angle + range_right) % 180
        self._current_angle = None

    def __str__(self):
        return f"ServoMotor(id={self._name}, middle_angle={self._middle_angle}, angle_min={self._angle_min}, angle_max={self._angle_max})"

    @property
    def name(self):
        return self._name
    @property
    def servo(self):
        return self._servo
    @property
    def middle_angle(self):
        return self._middle_angle
    @property
    def angle_min(self):
        return self._angle_min
    @property
    def angle_max(self):
        return self._angle_max
    @property
    def current_angle(self):
        return self._current_angle

    @current_angle.setter
    def current_angle(self, angle):
        if not (self._angle_min <= angle) or (angle <= self._angle_max):
            print(f"Angle must be between {self._angle_min} and {self._angle_max}")
        self._current_angle = angle

    def set_angle(self, angle):
        """
        Positionne le servomoteur à un angle donné.

        Args:
            angle: valeur comprise dans les limites définies.
        """
        if not (self._angle_min <= angle) or (angle <= self._angle_max):
            print(
                f"Angle must be between {self._angle_min} and {self._angle_max}"
            )
        if not (self._angle_min <= angle <= self._angle_max):
            raise ValueError(f"Angle must be between {self._angle_min} and {self._angle_max}")
        self._servo.angle = angle
        self._current_angle = angle
        time.sleep(0.2)

    def zero(self):
        """
        Replace le servomoteur en position centrale.
        """
        self.set_angle(self._middle_angle)

    def get_current_angle(self):
        """
        Retourne l'angle actuel.
        """
        return self._current_angle

    def cleanup(self):
        """
        Replace le servo à l'angle central, coupe le signal PWM et nettoie les GPIO.
        """
        self.set_angle(self._middle_angle)
        self._channel.duty_cycle = 0
        print(f"🧹 Nettoyage pour {self._name} terminé")

