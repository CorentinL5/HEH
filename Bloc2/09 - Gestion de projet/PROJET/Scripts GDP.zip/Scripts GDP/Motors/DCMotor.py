class DCMotor:
    id = 0

    def __init__(self, in1, in2, pca9685, channel):
        """
        - in1, in2 : GPIO de direction
        - pca9685 : instance du contrôleur PCA9685
        - channel : canal utilisé pour le signal PWM (0 à 15)
        """
        DCMotor.id += 1
        self._name = f"DCMotor_{DCMotor.id}"
        self._in1 = in1
        self._in2 = in2
        self._pca = pca9685
        self._channel = channel

        import RPi.GPIO as GPIO
        self.GPIO = GPIO

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(in1, GPIO.OUT)
        GPIO.setup(in2, GPIO.OUT)

    @property
    def name(self):
        return self._name

    def set_speed(self, speed):
        """
        Définit la vitesse du moteur (0-100%) en PWM via PCA9685
        """
        speed = max(0, min(speed, 100))  # clamp
        duty_cycle = int((speed / 100.0) * 0xFFFF)  # 16 bits
        self._pca.channels[self._channel].duty_cycle = duty_cycle

    def forward(self):
        self.GPIO.output(self._in1, self.GPIO.HIGH)
        self.GPIO.output(self._in2, self.GPIO.LOW)

    def backward(self):
        self.GPIO.output(self._in1, self.GPIO.LOW)
        self.GPIO.output(self._in2, self.GPIO.HIGH)

    def stop(self):
        self.GPIO.output(self._in1, self.GPIO.LOW)
        self.GPIO.output(self._in2, self.GPIO.LOW)
        self._pca.channels[self._channel].duty_cycle = 0

    def cleanup(self):
        self.stop()
        self.GPIO.cleanup([self._in1, self._in2])
        print(f"🧹 Nettoyage pour {self._name} terminé")
