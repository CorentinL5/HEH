from model.Motors.DCMotor import DCMotor

class MotorController:
    def __init__(self, in1: int, in2: int, pca9685, channel: int):
        """
        Contrôleur de moteur DC avec direction via GPIO et vitesse via PCA9685.
        - in1, in2 : GPIOs de direction
        - pca9685 : instance du contrôleur PCA9685 (déjà initialisée)
        - channel : canal PWM (0 à 15)
        """
        self._model = DCMotor(in1=in1, in2=in2, pca9685=pca9685, channel=channel)

    def avancer(self, speed: int = 100):
        """
        Fait avancer le moteur à une vitesse donnée (en %)
        """
        self._model.set_speed(speed)
        self._model.forward()
        print(f"🟢 Avance à {speed}%")

    def reculer(self, speed: int = 100):
        """
        Fait reculer le moteur à une vitesse donnée (en %)
        """
        self._model.set_speed(speed)
        self._model.backward()
        print(f"🔙 Recule à {speed}%")

    def stop(self):
        self._model.stop()
        print(f"⏹️ Stop {self._model.name}")

    def cleanup(self):
        """
        Nettoie les GPIO utilisés
        """
        self._model.cleanup()
