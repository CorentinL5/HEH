from model.Motors.ServoMotor import ServoMotor


class ServoController:
    def __init__(self, pca9685, channel, range_left=30, range_right=30, middle_angle=130):
        self._model = ServoMotor(pca9685=pca9685, channel=channel, range_left=range_left, range_right=range_right, middle_angle=middle_angle)

    def move_servo_to(self, angle):
        try:
            if angle < 0 or angle > 180:
                raise ValueError(f"Angle doit être entre 0 et 180. Tentative de {angle}°.")
            self._model.set_angle(angle)
        except ValueError as e:
            return f"Erreur : {e}"

    def __str__(self):
        return self._model

    def zero(self):
        self._model.zero()
        return f"Servo zéroté à {self._model.get_current_angle()}°"

    def get_position(self):
        angle = self._model.get_current_angle()
        return f"Angle actuel : {angle}°"

    def cleanup(self):
        self._model.cleanup()
        return "ServoController nettoyé"
