from controller.DCMotorController import MotorController
from controller.ServoMotoController import ServoController

from threading import Thread
import time
import board
import busio
from adafruit_pca9685 import PCA9685


def moteur_avance(moteur, speed, duration):
    moteur.avancer(speed)
    time.sleep(duration)
    moteur.stop()

def moteur_recule(moteur, speed, duration):
    moteur.reculer(speed)
    time.sleep(duration)
    moteur.stop()

def sequence_danse(moteur_a, moteur_b, servo):
    print("🟢 Phase 1 : Avance tout droit")
    servo.move_servo_to(130)
    t2 = Thread(target=moteur_avance, args=(moteur_b, 90, 5))
    t1 = Thread(target=moteur_avance, args=(moteur_a, 90, 5))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    print("↪️ Phase 2 : Courbe à gauche")
    servo.move_servo_to(95)
    t1 = Thread(target=moteur_avance, args=(moteur_a, 70, 1.5))
    t2 = Thread(target=moteur_avance, args=(moteur_b, 40, 1.5))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    print("↩️ Phase 3 : Courbe à droite")
    servo.move_servo_to(165)
    t1 = Thread(target=moteur_avance, args=(moteur_a, 40, 1.5))
    t2 = Thread(target=moteur_avance, args=(moteur_b, 70, 1.5))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    print("🕹️ Phase 4 : Marche arrière + centre")
    servo.zero()
    t1 = Thread(target=moteur_recule, args=(moteur_a, 50, 1.5))
    t2 = Thread(target=moteur_recule, args=(moteur_b, 50, 1.5))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    print("✅ Chorégraphie terminée !")


if __name__ == "__main__":
    # Setup PCA pour le servo
    i2c = busio.I2C(board.SCL, board.SDA)
    pca = PCA9685(i2c)
    pca.frequency = 50

    # Initialisation moteurs
    moteur_a = MotorController(in1=27, in2=22, pwm_pin=5)
    moteur_b = MotorController(in1=17, in2=18, pwm_pin=4)

    # Initialisation servo (canal 0 par défaut)
    servo = ServoController(pca9685=pca, channel=0, range_left=35, range_right= 35, middle_angle=130)

    try:
        print("🟢 Les deux moteurs AVANCENT à 60% (synchro)")
        t1 = Thread(target=moteur_avance, args=(moteur_a, 60, 2))
        t2 = Thread(target=moteur_avance, args=(moteur_b, 60, 2))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        print("🔄 Les deux moteurs RECULENT à 40% (synchro)")
        t1 = Thread(target=moteur_recule, args=(moteur_a, 40, 2))
        t2 = Thread(target=moteur_recule, args=(moteur_b, 40, 2))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        print(servo.get_position())
        print("🛞 Test du servo : position gauche")
        servo.move_servo_to(95)
        time.sleep(1)

        print(servo.get_position())
        print("🛞 Position droite")
        servo.move_servo_to(165)
        time.sleep(1)

        print(servo.get_position())
        print("🛞 Retour au centre (zéro)")
        print(servo.zero())
        time.sleep(1)
        servo.move_servo_to(130)
        time.sleep(1)

        print(servo.get_position())

        print("🔄 Démarrage de la chorégraphie")
        sequence_danse(moteur_a, moteur_b, servo)


    except KeyboardInterrupt:
        print("❌ Interruption par l'utilisateur")
        moteur_a.stop()
        moteur_b.stop()

    finally:
        print("🧹 Nettoyage des GPIO et du PCA9685")
        servo.cleanup()
        moteur_a.cleanup()
        moteur_b.cleanup()
        pca.deinit()
