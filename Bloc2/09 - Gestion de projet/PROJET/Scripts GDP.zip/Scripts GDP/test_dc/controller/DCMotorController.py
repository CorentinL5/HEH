from model.Motors.DCMotor import DCMotor

class MotorController:
    def __init__(self, in1: int, in2: int, pwm_pin: int):
        """
        Contrôleur de moteur DC basé sur un pont en H (L298N).
        - in1 : GPIO IN1
        - in2 : GPIO IN2
        - pwm_pin : GPIO pour le signal PWM (ENA ou ENB)
        """
        self._model = DCMotor(in1=in1, in2=in2, pwm_pin=pwm_pin)

    def avancer(self, speed: int = 100):
        """
        Fait avancer le moteur à une vitesse donnée (en %).
        """
        self._model.set_speed(speed)
        self._model.forward()
        print(f"🟢 Avance à {speed}%")

    def reculer(self, speed: int = 100):
        """
        Fait reculer le moteur à une vitesse donnée (en %).
        """
        self._model.set_speed(speed)
        self._model.backward()
        print(f"🔙 Recule à {speed}%")

    def stop(self):
            self._model.stop()

    def cleanup(self):
        """
        Nettoie les GPIO utilisés.
        """
        self._model.cleanup()