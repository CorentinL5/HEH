import RPi.GPIO as GPIO


class DCMotor:
    """
    Classe représentant le modèle d'un moteur à courant continu (DC) contrôlé par un pont en H (L298N).
    """
    id = 0

    def __init__(self, in1, in2, pwm_pin):
        DCMotor.id += 1
        self._name = f"DCMotor_{DCMotor.id}"
        self._in1 = in1
        self._in2 = in2
        self._pwm_pin = pwm_pin
        self._pwm = None

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self._in1, GPIO.OUT)
        GPIO.setup(self._in2, GPIO.OUT)

        if self._pwm_pin is not None:
            GPIO.setup(self._pwm_pin, GPIO.OUT)
            self._pwm = GPIO.PWM(self._pwm_pin, 1000)  # PWM à 1kHz
            self._pwm.start(0)

    @property
    def name(self):
        return self._name is not None

    @property
    def pwm_pin(self):
        return self._pwm_pin

    @property
    def in1(self):
        return self._in1

    @property
    def in2(self):
        return self._in2

    def set_speed(self, speed):
        if not self._pwm:
            raise RuntimeError("PWM non configuré. Vitesse non contrôlable.")
        speed = max(0, min(speed, 100))  # clamp la valeur
        self._pwm.ChangeDutyCycle(speed)

    def forward(self):
        GPIO.output(self._in1, GPIO.HIGH)
        GPIO.output(self._in2, GPIO.LOW)

    def backward(self):
        GPIO.output(self._in1, GPIO.LOW)
        GPIO.output(self._in2, GPIO.HIGH)

    def stop(self):
        GPIO.output(self._in1, GPIO.LOW)
        GPIO.output(self._in2, GPIO.LOW)
        if self._pwm:
            self._pwm.ChangeDutyCycle(0)

    def cleanup(self):
        """
        Nettoie les GPIO utilisés.
        """
        self.stop()
        if self._pwm:
            self._pwm.stop()
        GPIO.cleanup(self._in1)
        GPIO.cleanup(self._in2)
        if self._pwm_pin:
            GPIO.cleanup(self._pwm_pin)
        print(f"🧹 Nettoyage des GPIO pour {self._name}")
