import toJSON from './toJSON.plugin';

export default toJSON;
