import { useState, useEffect } from 'react';
import Gallery from './Components/Gallery';

function getLink(page) {
    return `https://picsum.photos/v2/list?limit=10&page=${page}`;
}

function App() {
    const [photos, setPhotos] = useState([]);

    useEffect(() => {
        fetch(getLink(3))
            .then(response => response.json())
            .then(data => {
                console.log(data); // Vérification dans la console
                setPhotos(data); // Utilise directement 'data' (pas data.photos)
            })
            .catch(error => console.error('Erreur lors du fetch :', error));
    }, []);

    return (
        <div style={{
            border: '3px solid blue',
            padding: '15px',
            backgroundColor: '#222',
            color: 'white',
            textAlign: 'center',
            borderRadius: '5px'
        }}>
            <h1>Application de galerie de photos</h1>
            <Gallery photos={photos} />
        </div>
    );
}

export default App;
