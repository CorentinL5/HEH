import { useState } from 'react';
import Photo from './Photo';

function Gallery({ photos }) {
    const [search, setSearch] = useState('');
    const [hideId, setHideId] = useState(false);

    const handleSearch = (e) => {
        setSearch(e.target.value);
    };

    const filteredPhotos = photos.filter(photo => photo.author.toLowerCase().includes(search.toLowerCase()));

    return (
        <div style={{
            padding: '15px',
            backgroundColor: '#222',
            color: 'white',
            textAlign: 'center',
            borderRadius: '5px',
            maxWidth: '500px',
            margin: 'auto'
        }}>
            <h1>Galerie de photos</h1>

            <div>
                <input
                    type="text"
                    placeholder="Search by author"
                    value={search}
                    onChange={handleSearch}
                    style={{ padding: '8px', width: '80%', marginBottom: '10px', borderRadius: '5px' }}
                /><br />
                <label>
                    <input
                        type="checkbox"
                        checked={hideId}
                        onChange={() => setHideId(!hideId)}
                    />
                    Hide id
                </label>
            </div>

            <div>
                {filteredPhotos.map(photo => (
                    <div key={photo.id} style={{ margin: '15px 0' }}>
                        <p style={{ fontWeight: 'bold' }}>
                            {photo.author} {!hideId && `#${photo.id}`}
                        </p>
                        <Photo id={photo.id} size={{ width: 300, height: 200 }} />
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Gallery;
