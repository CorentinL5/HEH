function Photo({ id, size }) {
    const { width, height } = size;
    const imageUrl = `https://picsum.photos/id/${id}/${width}/${height}`;

    return (
        <img
            src={imageUrl}
            alt={`Photo ${id}`}
            style={{
                width: `${width}px`,
                height: `${height}px`,
                objectFit: 'cover',
                borderRadius: '5px'
            }}
        />
    );
}

export default Photo;
