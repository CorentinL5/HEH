# React + Vite

Ce projet utilise [Vite](https://vitejs.dev/) avec React pour un démarrage rapide, incluant HMR (Hot Module Replacement) et une configuration ESLint minimale.

## Fonctionnement

Deux plugins officiels sont disponibles :

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react) (basé sur Babel)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) (basé sur SWC)

## Installation

1. Clonez ou dézippez le projet
2. Dans le terminal, exécutez :

```bash
npm install
````

3. Lancez le projet en mode développement :

```bash
npm run dev
```

## Infos utiles

* `node_modules` n'est **pas inclus** dans ce dépôt ou ce zip pour alléger le transfert.
* Assurez-vous d'avoir Node.js installé ([Télécharger Node.js](https://nodejs.org))
