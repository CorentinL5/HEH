# Fonction pour écrire dans le fichier log
function Write-Log {
    param ([string]$Message)
    $TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$TimeStamp - $Message" | Out-File -FilePath $LogFile -Append
}

# Variables
$BaseBackupPath = "C:\Backup"
$CurrentDateTime = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"  # Formatage de la date et heure
$BackupPath = "$BaseBackupPath\backup-$CurrentDateTime"  # Dossier de sauvegarde unique
$DHCPFile = "$BackupPath\DHCP_Backup.xml"
$DNSBackupPath = "$BackupPath\DNS"
$LogFile = "$BackupPath\BackupLog.txt"
$ComputerName = "winServG2"

# Créer le dossier de sauvegarde unique
if (!(Test-Path -Path $BackupPath)) {
    New-Item -ItemType Directory -Force -Path $BackupPath | Out-Null
    Write-Log "Dossier de sauvegarde créé : $BackupPath"
}
if (!(Test-Path -Path $DNSBackupPath)) {
    New-Item -ItemType Directory -Force -Path $DNSBackupPath | Out-Null
    Write-Log "Dossier DNS créé : $DNSBackupPath"
}

# Initialiser le log
Write-Log "Début de la sauvegarde des serveurs ($ComputerName)."

# Sauvegarde DHCP
Write-Log "Démarrage de la sauvegarde DHCP..."
try {
    Export-DhcpServer -ComputerName $ComputerName -File $DHCPFile -Leases
    Write-Log "Sauvegarde DHCP réussie : $DHCPFile"
} catch {
    Write-Log "Erreur lors de la sauvegarde DHCP : $_"
}

# Sauvegarde DNS
Write-Log "Démarrage de la sauvegarde DNS..."
$Zones = Get-DnsServerZone | Where-Object { $_.ZoneType -eq "Primary" }  # Filtrer les zones primaires
foreach ($Zone in $Zones) {
    $ZoneFile = "$DNSBackupPath\$($Zone.ZoneName).dns"
    try {
        dnscmd /zoneexport $Zone.ZoneName $ZoneFile
        Write-Log "Zone DNS sauvegardée : $Zone.ZoneName -> $ZoneFile"
    } catch {
        Write-Log "Erreur lors de la sauvegarde DNS pour la zone $Zone.ZoneName : $_"
    }
}

Write-Log "Sauvegarde terminée pour $ComputerName. Les fichiers sont disponibles dans $BackupPath."
