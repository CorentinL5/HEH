list = [
"fichiersTXT/hist (1).txt",
"fichiersTXT/hist (2).txt",
"fichiersTXT/hist (3).txt",
"fichiersTXT/hist (4).txt",
"fichiersTXT/hist (5).txt",
"fichiersTXT/hist (6).txt",
"fichiersTXT/2/hist (1).txt",
"fichiersTXT/2/hist (2).txt",
"fichiersTXT/2/hist (3).txt",
"fichiersTXT/2/hist (4).txt",
"fichiersTXT/2/hist (5).txt",
"fichiersTXT/2/hist (6).txt",
]

def find_word_function(wordToFind):
    wordFindedCount = 0
    for path in list:
        with open(path, "r", encoding="utf-8") as openFile:
            for line in openFile:
                if wordToFind in line:
                    wordFindedCount += 1
    return wordFindedCount

print(find_word_function("mot_a_trouver"))
