// Importation des dépendances Obsidian
const { Plugin, MarkdownRenderer } = require('obsidian');

// Fonction d'exportation en PDF
async function exportToPDF(editor, app) {
    // Récupérer le contenu du fichier actuel
    const content = editor.getValue();

    // Récupérer les images avec la syntaxe ![[image]]
    const imageRegex = /!\[\[(.*?)\]\]/g;

    // Variable pour le contenu transformé
    let transformedContent = content;

    let match;
    while ((match = imageRegex.exec(content)) !== null) {
        const imagePath = match[1];

        // Recherche le fichier image dans le vault
        const file = app.vault.getAbstractFileByPath(imagePath);

        if (file && file instanceof app.vault.TFile) {
            // Lit l'image en base64 pour l'injecter dans le PDF
            const imageData = await app.vault.readBinary(file);
            const base64Image = arrayBufferToBase64(imageData);

            // Remplace la syntaxe par une balise <img> avec les données base64
            transformedContent = transformedContent.replace(match[0], `<img src="data:image/png;base64,${base64Image}" alt="${imagePath}" />`);
        }
    }

    // Créer le PDF avec jsPDF
    const jsPDF = window.jspdf.jsPDF;
    const doc = new jsPDF();

    // Ajoute le contenu transformé à la page PDF
    doc.text(transformedContent, 10, 10);

    // Sauvegarde le PDF avec un nom approprié
    doc.save('exported_note.pdf');
}

// Fonction utilitaire pour convertir un ArrayBuffer en base64
function arrayBufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}

// Création du plugin
module.exports = class ExportToPDFPlugin extends Plugin {
    async onload() {
        console.log('Plugin Export to PDF chargé');

        // Ajoute une commande dans la palette de commande pour exporter en PDF
        this.addCommand({
            id: 'export-to-pdf',
            name: 'Exporter la note en PDF',
            editorCallback: (editor) => {
                exportToPDF(editor, this.app);
            }
        });
    }

    onunload() {
        console.log('Plugin Export to PDF déchargé');
    }
};
